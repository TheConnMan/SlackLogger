package com.theconnman.slacklogger

class TestController {

    def index() {
		log.info 'Testing logger'
	}
}
